import cv2
import pytesseract

pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files (x86)/Tesseract-OCR/tesseract.exe'
tessdata_dir_config = '--tessdata-dir"C:/Program Files (x86)/Tesseract-OCR"'
img = cv2.imread('1.jpg')
img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
# print(pytesseract.image_to_string(img,config=tessdata_dir_config))

###Detecting
# print(pytesseract.image_to_boxes(img,config=tessdata_dir_config))
hImg,wImg,_= img.shape
boxs = pytesseract.image_to_boxes(img,config=tessdata_dir_config)
# print(boxs)
for i in boxs.splitlines():
    # print(i)
    i = i.split()
    # print(i)
    x,y,w,h = int(i[1]),int(i[2]),int(i[3]),int(i[4])
    cv2.rectangle(img,(x,hImg-y),(w,hImg-h),(0,0,255),2)
    cv2.putText(img,i[0],(x,hImg-y+27),cv2.FONT_HERSHEY_COMPLEX,1,(50,50,255),2)

print('บ๊ายบายจ้า')


cv2.imshow('Result',img)
cv2.waitKey(0)